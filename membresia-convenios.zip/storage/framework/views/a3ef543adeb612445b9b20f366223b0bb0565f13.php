<div class="h-32 p-10 border-b border-gray-300">
    <h3 class="text-2xl"><?php echo e($slot); ?></h3>
</div><?php /**PATH C:\Users\Laura\Documents\Proyectos\membresia-convenios\resources\views/components/title-page.blade.php ENDPATH**/ ?>