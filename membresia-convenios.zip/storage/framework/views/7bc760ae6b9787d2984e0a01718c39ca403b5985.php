<div>
    <h1 class="text-3xl mb-4"><?php echo e($slot); ?></h1>
</div><?php /**PATH C:\Users\Laura\Documents\Proyectos\membresia-convenios\resources\views/components/title.blade.php ENDPATH**/ ?>