<div>
    <img src="<?php echo e(asset($logo)); ?>" alt="Logo de la empresa" width="128px">
</div>
<?php /**PATH C:\Users\Laura\Documents\Proyectos\membresia-convenios\resources\views/livewire/logo/logo-login.blade.php ENDPATH**/ ?>