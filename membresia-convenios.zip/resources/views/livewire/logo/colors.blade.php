<style>
    .bg-nav{
        background-color: {{$fondo1}};
    }
    .bg-main{
        background-color: {{$fondo2}};
    }
    .color-nav{
        color:{{$color1}}!important;
    }
    .color-main{
        color:{{$color2}};
    }
</style>