<div>
    <h1 class="text-3xl mb-4">{{$slot}}</h1>
</div>