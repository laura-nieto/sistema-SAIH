<div class="h-32 p-10 border-b border-gray-300">
    <h3 class="text-2xl">{{$slot}}</h3>
</div>